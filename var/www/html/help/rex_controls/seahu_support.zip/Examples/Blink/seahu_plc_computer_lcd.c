/****************************************************************
*                                                               *
*   REXLANG - SEAHU SH017 display controler for                 *
*	monochrome LCD DISPLAY 128x64px                             *
*																*
*	implemented function:                                       *
*						clear display                           *
*                       print text into x,y position            *
*						print inversion text into x,y position  *
*						draw image (.tif monochrome 128x64px)   *
*                                                               *
*   (c) Ing. Ondrej Lycka, www.seahu.cz                         *
*                                                               *
*****************************************************************/

/*
	input(0) - text for display
	input(1) - clear flag 1=clear, 0=no clear
	input(2) - inversion text bacground flag 1=inversion, 0= noinversion
	input(3) - number of columbs position for print text(from top left conner) values: 0-15
	input(4) - number of rows position for print text(from top left conner) values: 0-3
	input(4) - filename with suffix with image (image must be located in /opt/seahu/lcd_images and mus have 128x64px resolution only blask and wihite - bes format is tiff

COMMENT: SEAHU SH017 (PiToDin) is PLC computer based on mini PC raspberryPI.
LCD is conected to raspberry PI via SPI interface, bat this is controled
throught simple TCP service (/opt/seahu/service_graph_lcd.py).
Simple TCP protocol:
# TCP server for print into display from more programs
# service care about framefuffer,so you can get content of dispalya
# service can display text or image
# actualy framebuffer store only text (ignore image and inversion text)
# protocol is very easy. Client send data on one packed with format explain bellow and close connection.
# Only when send "g" client wait to answer where get conntent of framebuffer and close connection.
# example of data:
#   "c" - clear lcd (no naswer)
#   "g" - return (answer) actual framebuffer (ignore inversion and image, only text).
#   "p,01,03,show text" - print "show text" on posicion x=1, y=3 (from top-left) (no answer)
#   "i,01,03,show text" - print inversion text "show text" on posicion x=1, y=3 (from top-left) (no answer)
#   "m,imagefile" - print image (must be black and white .tiff size 128x64 pixels stred at directory: (no answer)

#PS: server is very easy. Serve only one connection at some time, therefore client must send requirement and.
# as quickly as possible connection close for release connection forother.
# Printed into display consume some time and if client try open connection beafore other ended then may bigger delay.

*/

#define CON_UDP      64
#define CON_TCPCLIENT 66
//#define RECEIVER_IP  0xC0A80274 //192.168.2.116
//#define SENDER_IP    0xC0A80274 //192.168.2.116
#define RECEIVER_IP  0x7F000001 //127.0.0.1
#define SENDER_IP    0x7F000001 //127.0.0.1
#define senderPort   10001
#define receiverPort 10000
#define BUFFER_SIZE  50    //maximum number of bytes to send

//assigning inputs to variables, these variables are READ-ONLY
//string parameter(0) text;
string input(0) text;	// text for display
long input(1) clear;     //integer number 1=clear display other duing nothing
long input(2) inversion;     //integer number 1=inversion backroub text
long input(3) x;     //integer number number of columbs (0-15)
long input(4) y;     //integer number number of rows (0-3)
string input(5) image;	// filename with suffix with image (image must be located in /opt/seahu/lcd_images and mus have 128x64px resolution only blask and wihite - bes format is tiff
//double input(4) signal2;   //real number to send to the receiver
//double input(5) signal3;   //real number to send to the receiver


//assigning variables to outputs, these variables are WRITE-ONLY
long output(15) handle;    //handle of the UDP socket
long output(1) finish; // if finish new print refer this pin to set 1 other 0

//declaration of variables
long hSendLoc;             //socket handle
long buffer[BUFFER_SIZE];  //buffer for incoming data
long dataCnt;              //number of bytes sent
long convData[2];          //array for data conversions
long i;
long cmp;
string send[BUFFER_SIZE];
string cmp_buf[BUFFER_SIZE];
string last_buf[BUFFER_SIZE];
string s_image[BUFFER_SIZE];
string s_text[BUFFER_SIZE];
string s_x[5];
string s_y[5];
string s_i[5];
string s_c[5];
string cmd[2];

/* Initialization of the REXLANG algorithm */
// the init procedure is executed once when the REXLANG function block initializes
int init(void)
{
	hSendLoc = -1;
	strcpy(last_buf,"");
	finish=0;
	return 0;
}

/* The body of the REXLANG algorithm */
// the main procedure is executed once in each sampling period
long main(void)
{
	// set default finish status
	finish=0;

	// get two cifers string number of X coordination
	s_x=long2str(x);
	if (strlen(s_x)<1) strcpy(s_x,"00");
	if (strlen(s_x)<2) {
		strcpy(s_x,"0");
		strcat(s_x,long2str(x));
	}

	// get two cifers string number of Y coordination
	s_y=long2str(y);
	if (strlen(s_y)<1) strcpy(s_y,"00");
	if (strlen(s_y)<2) {
		strcpy(s_y,"0");
		strcat(s_y,long2str(y));
	}

	//prepare inversion
	if (inversion==1) strcpy(s_i,"i");
	else strcpy(s_i,"p");

	//prepare clear
	if (clear==1) strcpy(s_c,"c");
	else strcpy(s_c,"n");
	
	//prepre image must be copy becouse for input/output/parameter not suported string function
	strcpy(s_image,image);

	//prepre text must be copy becouse for input/output/parameter not suported string function
	strcpy(s_text,text);
	
	// complete string for compare with string in last calling
	strcpy(cmp_buf,"");
	strcat(cmp_buf,s_c);
	strcat(cmp_buf,s_i);
	strcat(cmp_buf,s_x);
	strcat(cmp_buf,s_y);
	strcat(cmp_buf,s_image);
	strcat(cmp_buf,s_text);
	
	// compare send and last_send mornaly use strcmp, bat this function in rex system have bug
	cmp=0;
	if (strlen(cmp_buf)==strlen(last_buf)){
		for(i=0; i<strlen(cmp_buf); i++){
			if (cmp_buf[i]!=last_buf[i]){
				cmp=-2;
				break;
			}
		}
	}
	else cmp=-1;

	if ( cmp==0) {
		handle = -10;
		return 0;  // is same as last do not need send again
	}
		
	//serve clear
	if (clear==1) {
		hSendLoc = OpenTCPcli("127.0.0.1", receiverPort);
		if (hSendLoc<0){
			//publishing the UDP communication handle through output signal (for 		debugging)
			handle = hSendLoc;
			return -1;
		}
	    Write(hSendLoc, "c");
	   	Close(hSendLoc);
	   	strcpy(last_buf,cmp_buf);
   		finish=1;
	}

	//serve image
	if (strlen(s_image)>0){
		strcpy(send,"m,");
		strcat(send,s_image);
		hSendLoc = OpenTCPcli("127.0.0.1", receiverPort);
		if (hSendLoc<0){
			//publishing the UDP communication handle through output signal (for 		debugging)
			handle = hSendLoc;
			return -1;
		}
    	Write(hSendLoc, send);
   		Close(hSendLoc);
	   	strcpy(last_buf,cmp_buf);
   		finish=1;
	}
	
	//if no text then end
	if (strlen(s_text)==0){
		handle = -11;
		return 0;
	}

	// prepare context of packet
	strcpy(send,"");
	strcat(send,s_i);
	strcat(send,",");
	strcat(send,s_x);
	strcat(send,",");
	strcat(send,s_y);
	strcat(send,",");
	strcat(send,text);

	hSendLoc = OpenTCPcli("127.0.0.1", receiverPort);
	if (hSendLoc<0){
	//publishing the UDP communication handle through output signal (for 		debugging)
		handle = hSendLoc;
		return -1;
	}
	//strcat(send,long2str(cmp));
    Write(hSendLoc, send);
   	Close(hSendLoc);
	strcpy(last_buf,cmp_buf);
	finish=1;
	return 0;
}

/* Closing the REXLANG algorithm */
//the exit procedure is executed once when the task is correctly terminated
// (system shutdown, downloading new control algorithm, etc.)
long exit(void)
{
	if(hSendLoc>=0) Close(hSendLoc);
  return 0;
}