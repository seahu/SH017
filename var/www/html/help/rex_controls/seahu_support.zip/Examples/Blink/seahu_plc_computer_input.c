/*******************************************************************
*
* REXLANG - write bit to i2c chip PCF8574
*           specialy write for support SEAHU PLC computer,
*           but my be general use
*           output(0) - return actual value of pin
*           parameter(0) - represantate seting bit as (binary bit mask)
*           parameter(1) - represantate init value as (binary mask for seting inputs pins, value pins defined as ouput during init proces is not changed)
*           parameter(2) - represantate i2c address
*           parameter fname - represantate i2c bus (e.g. set it to /dev/i2c-1 on the Raspberry Pi minicomputer)
********************************************************************/

#define I2CDEV_FNAME "/dev/i2c-1" // I2C device is defined by the fname parameter of the REXLANG block (e.g. set it to /dev/i2c-1 on the Raspberry Pi minicomputer)

//assigning inputs to variables, these variables are READ-ONLY
long output(0) digital_in; //the signal controlling the inputs is connected to output y0 of the REXLANG block
long parameter(0) PIO_mask;
  // SEAHU plc computer use next values:
  // PIO_mask = bit mask representate PIO at PCF8574 on baseboard
  // 0x01 - relay-0 (output)
  // 0x02 - relay-1 (output)
  // 0x04 - relay-2 (output)
  // 0x08 - relay-3 (output)
  // 0x10 - in-1    (input)
  // 0x20 - in-2    (input)
  // 0x40 - out-1   (output)
  // 0x80 - out-2   (output)
  // PIO_mask = bit mask representate PIO at PCF8574 on LCD and key board
  // 0x01 - key left  (input)
  // 0x02 - key right (input)
  // 0x04 - key up    (input)
  // 0x08 - key down  (input)
  // 0x10 - key OK    (input)
  // 0x20 - key ESC   (input)
  // 0x40 - LCD light (output)
long parameter(1) init_mask;
  // bit mask controls type POI 0-only output value 0, 1-output value 1 or input (open colector with pullup resistor)
  // SEAHU plc computer use next values:
  // 0x30 for SEAHU017 baseboard (set pin4,5 as input) (bit_0-relay0, bit_1-realy1, bit_2-relay2, bit_3-relay3, bit_4-input1, bit_5-input2, bit_6-output1, bit_7-output2)
  // 0x3F for SEAHU017 LCD and key board (set pin0,1,2,3,4,5 as input) (bit_0-key left, bit_1-key right, bit_2-key up, bit_3-key up, bit_4-key OK, bit_5-key ESC, bit_6-LCD backlight, bit_7-not use)
long parameter(2) i2c_chip_address;
  // SEAHU plc computer use next address:
  // 0x38 is adress PCF8574 on baseboard (4xrelays, 2xinput, 2x output)
  // 0x3c is adress PCF8574 on SEAHU017 LCD and key board (6xkey-input, 1x output-LCD light)


//declaration of variables
long i2c_bufTx[1]; //buffer for transmitting data
long i2c_bufRx[1]; //buffer for receiving data
long i2c_bus_handle;
long i2c_write_count;
long i2c_read_count;
long i2c_ret_fun;

//the init procedure is executed once when the REXLANG function block initializes
long init(void)
{
    //open i2c
    i2c_bus_handle = OpenI2C(I2CDEV_FNAME); // open I2C bus

    //Setting type PIO on (PCF8574 at 0x20)
    i2c_ret_fun = I2C(i2c_bus_handle, i2c_chip_address, i2c_bufTx, 0, i2c_bufRx, 1);
    i2c_bufTx[0]=i2c_bufRx[0]|init_mask;  // merge actual value witch init_mask to save output values
    i2c_ret_fun = I2C(i2c_bus_handle, i2c_chip_address, i2c_bufTx, 1, i2c_bufRx, 0);

    //close i2c
    if(i2c_bus_handle>=0) Close(i2c_bus_handle); // close I2C bus

    return 0;
}

//the main procedure is executed once in each sampling period
long main(void)
{
    i2c_bus_handle = OpenI2C(I2CDEV_FNAME); // open I2C bus

    //Get PIO at PCF8574
    i2c_ret_fun = I2C(i2c_bus_handle, i2c_chip_address, i2c_bufTx, 0, i2c_bufRx, 1);
    if ( (i2c_bufRx[0] & PIO_mask)>0 ) digital_in=1;
    else digital_in=0;

    if(i2c_bus_handle>=0) Close(i2c_bus_handle); // close I2C bus
    return 0;
}

//the exit procedure is executed once when the task is correctly terminated
// (system shutdown, downloading new control algorithm, etc.)
long exit(void)
{
  return 0;
}