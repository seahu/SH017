﻿Raspberry Pi as a simple thermostat 
===================================
 
This folder contains the source files for the demonstration project on using
the REX Control System on the Seahu SH017 PLC computer. 

In this example the Seahu SH017 is configured to act as a simple thermostat. 
The temperature is measured by the 1-Wire DS18B20 sensor with relay1 
on and off with a hysteresis of 0.5°C.

The measured temperature and status of the relay is recorded in the TRND blocks
which allow displaying of the trends (graphs) in the RexView diagnostic tool. 

## Timing of the project ##

The algorithm runs each 500 milliseconds (0.5 s). See the EXEC function block,  
tick x ntick0 = 0.05 x 10 = 0.5 

## Prerequisites ##
- RexCore, RPiDrv and OwsDrv modules must be installed and running on the target 
  device (Raspberry Pi).
- Owserver (part of the OWFS package) must be installed, correctly configured 
  and running on the Raspberry Pi.
- The DS18B20 temperature sensor must be connected. See the attached wiring 
  diagram.

## Running the example ##
- The **exec.mdl* file is the project main file.
- Open it with *RexDraw*.
- Specify the 64-bit ROM ID of the attached temperature sensor. See the 1-Wire 
  driver manual below.
- Compile and download it to the target device.
- Switch to online mode and watch the algorithm (use Target->Monitor selection 
  to display data).

## Documentation ##

- **Press F1 for help** on the selected function block in the *RexDraw* program.
- [Getting started with REX on the Raspberry Pi minicomputer](http://www.rexcontrols.com/media/DOC/ENGLISH/REX_Getting_Started_RasPi_ENG.pdf)
- [RPiDrv - Raspberry Pi driver (including PiFace Digital, UniPi, Intellisys PIO)](http://www.rexcontrols.com/media/DOC/ENGLISH/RPiDrv_ENG.pdf)
- [OwsDrv - 1-Wire driver](http://www.rexcontrols.com/media/DOC/ENGLISH/OwsDrv_ENG.pdf)
- [Function blocks of the REX Control System](http://www.rexcontrols.com/media/HTML/DOC/ENGLISH/index.html)
- [Complete documentation of the REX Control System](http://www.rexcontrols.com/documentation-and-support)

## Additional information ##

- Seahu is a trademark of the [Seahu company](http://www.seahu.cz).
- 1-Wire is a trademark of [Maxim Integrated](http://www.maxim-ic.com).
- Visit the [REX Controls company webpage](http://www.rexcontrols.com) 
for more information about the example projects and developing advanced 
automation and control solutions using the REX Control System.


